let codemirror_editor;
let dokie = $(document);
let timeout_delay = 0;
let delay;

let function_keymap_editor = [
    { "Alt-B": function (cm) { insertStringInDocument('<br>', codemirror_editor); } },
    { "Alt-P": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<p>'); } },
    { "Alt-D": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<div>'); } },
    { "Alt-S": function (cm) { insertStringInDocument('<p>&nbsp;</p>', codemirror_editor); } },
    { "Alt-L": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<li>'); } },
    { "Alt-O": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<ol>'); } },
    { "Alt-N": function (cm) { convertSelectionToList(codemirror_editor); } },
    { "Ctrl-B": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<b>'); } },
    { "Ctrl-U": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<u>'); } },
    { "Ctrl-I": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<i>'); } },
    { "Alt-1": function (cm) { key_function_editor(codemirror_editor, 'MAJOR ITEM'); } },
    { "Alt-2": function (cm) { key_function_editor(codemirror_editor, 'MEDIUM ITEM'); } },
    { "Alt-3": function (cm) { key_function_editor(codemirror_editor, 'SMALL ITEM'); } },
    { "Alt-Q": function (cm) { key_function_editor(codemirror_editor, 'QUESTION'); } },
    { "Ctrl-1": function (cm) { key_function_editor(codemirror_editor, 'FRAME IMPORTANT'); } },
    { "Ctrl-2": function (cm) { key_function_editor(codemirror_editor, 'FRAME REFERENCE'); } },
    { "Ctrl-3": function (cm) { key_function_editor(codemirror_editor, 'FRAME SUPPLEMENT'); } },
    { "Ctrl-4": function (cm) { key_function_editor(codemirror_editor, 'FRAME UPDATE'); } },
    { "Ctrl-5": function (cm) { key_function_editor(codemirror_editor, 'FRAME KNOWLEDGE'); } },
    { "Alt-Y": function (cm) { change_fw(); } },
    { "Alt-R": function (cm) { fullwidth_selected(); } },
    { "Alt-I": function (cm) { key_function_editor(codemirror_editor, 'NEW IMAGE'); } },
    { "Alt-K": function (cm) { key_function_editor(codemirror_editor, 'UPDATE IMAGE'); } },
    { "Alt-A": function (cm) { key_function_editor(codemirror_editor, 'ACCORDION'); } },
    { "Alt-U": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<ul>'); } },
    { "Alt-T": function (cm) { key_function_editor(codemirror_editor, 'BACK TOP'); } },
    { "Ctrl-/": function (cm) { toggleCommentInEditor(codemirror_editor); } },
    { "F1": function (cm) { show_help(); } },
    { "Shift-Alt-F": function (cm) { beautifyHtmlInEditor(codemirror_editor); } },
    { "Shift-Alt-M": function (cm) { minify_codein_editor(codemirror_editor); } },
    { "Ctrl-Alt-F": function (cm) { fix_code_editor(codemirror_editor); } },
    { "Ctrl-M": function (cm) { img_indicator(codemirror_editor); } },
    { "Ctrl-L": function (cm) { insertStringInDocument(`style="list-style-type: '(1) '"`, codemirror_editor); } },
    { "Ctrl-R": function (cm) { modifySelectedTextInEditor(codemirror_editor, '<font style="color:#ff0000;">'); } }
];

// document.addEventListener('DOMContentLoaded', async (e) => {

// });

$(document).ready(async function () {
    load_summernote();
    load_codemirror();   
    setSummernoteHeight();
    $(window).resize(function () {        
        setSummernoteHeight();
    });
});

const load_summernote = () => {

    $(document).find('#summernote').summernote({
        height: 300,
        indentUnit: 3,
        disableDragAndDrop: true,
        followingToolbar: false,
        dialogsInBody: true,
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['fontname', ['fontname']],
            ['fontsize', ['fontsize']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen']]
        ],
        fontNames: [
            'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New',
            'Helvetica Neue', 'Helvetica', 'Impact', 'Lucida Grande',
            'Tahoma', 'Times New Roman', 'Verdana', 'Georgia'
        ],

        popover: {
            table: [
                ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
                ['delete', ['deleteRow', 'deleteCol', 'deleteTable']]
            ],
            image: [
                ['image', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
                ['float', ['floatLeft', 'floatRight', 'floatNone']],
                ['remove', ['removeMedia']]
            ],
            link: [
                ['link', ['linkDialogShow', 'unlink']]
            ],

            air: [
                ['style', ['style']],
                ['color', ['color']],
                ['font', ['bold', 'underline', 'clear']],
                ['para', ['ul', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture']]
            ]
        },

        callbacks: {
            onInit: function () {
                // setSummernoteHeight();
            },

            onChangeCodeview: function () {
                clearTimeout(delay);
            },
            onChange: function (contents, $editable) {
                //$(document).find("#custom_popup").css("display","none");    
                if (isCodeMirrorNotFocused() === true) {
                    codemirror_editor.setValue(contents);
                }

                change_in_editor = 0;
                clearTimeout(delay);
            },

            onKeydown: function (e) {
                // $(document).find("#custom_popup").css("display", "none");
            },

            onMousedown: function (e) {
                //$('.answer').summernote({airMode: true});
            },

            onKeyup: function (e) {
                // setTimeout(function () {
                // }, 200);
            },

            onBlurCodeview: function () {
                // codemirror_editor.getDoc().setValue($('#summernote').summernote('code'));
            },

            onBlur: function () {
                //$(document).find("#custom_popup").css("display","none");
                // if ($('#summernote').summernote('code').length != codemirror_editor.getValue().length) {
                //     codemirror_editor.setValue($('#summernote').summernote('code'));
                //     //alert("test")
                //     //codemirror_editor.setValue(remove_ids($('#summernote').summernote('code')));
                // }
            }
        }
    })

};

const load_codemirror = async () => {
    codemirror_editor = CodeMirror.fromTextArea(document.getElementById('cm-editor'), {
        mode: "htmlmixed",
        theme: "monokai",
        lineNumbers: true,
        dragDrop: true,
        lineWrapping: true,
        foldGutter: true,
        autoCloseTags: true,
        gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
    });

    const code_mirror_initialize = (e) => {

        for (let i = 0; i < function_keymap_editor.length; i++) {
            e.addKeyMap(function_keymap_editor[i]);
        }

        e.on("change", function () {
            default_editor = 1;
            clearTimeout(timeout_delay);
            timeout_delay = setTimeout(updateSummernotePreview(e), 300);
            // var cursor = codemirror_editor.getCursor();
            // codemirror_editor.setCursor({ line: cursor.line, ch: cursor.ch });
        });

        e.on("mousedown", function () {
            $(document).find("#custom_popup").css("display", "none");
            // var cursor = codemirror_editor.getCursor();
            // show_error(cursor.line);
            // codemirror_editor.setCursor({ line: 2, ch: 2 });
        });

        e.focus();

    }

    code_mirror_initialize(codemirror_editor);

};


const insertStringInDocument = (s, e) => {
    if (!s || !e) {
        console.error("Invalid input: string or event object is missing.");
        return;
    }

    var doc = e.getDoc();
    if (!doc) {
        console.error("Document not found.");
        return;
    }

    var cursor = doc.getCursor();
    if (!cursor) {
        console.error("Cursor not found.");
        return;
    }

    var pos = {
        line: cursor.line,
        ch: cursor.ch
    };

    // Replace HTML entities with their corresponding characters
    s = s.replace(/&quot;/gi, "'")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">");

    doc.replaceRange(s, pos);
};

const modifySelectedTextInEditor = (editor, searchString) => {
    if (!editor || !searchString) {
        console.error("Invalid input: editor or search string is missing.");
        return;
    }

    var selectedText = editor.getSelection();
    var searchLength = searchString.length;
    var selectedStart = selectedText.substring(0, searchLength);

    if (selectedStart === searchString) {
        // Remove the search string from the selection
        var remainingText = selectedText.substr(searchLength);
        editor.replaceSelection(remainingText);
    } else {
        // Wrap the selected text with the search string and a closing tag
        var closingTag = searchString.replace('<', '</').replace(' style="color:#ff0000;"', '');
        replaceTextInEditor(searchString + selectedText + closingTag, editor);
    }
};

const replaceTextInEditor = (text, editor) => {
    editor.replaceSelection(text);
};

const toggleCommentInEditor = (editor) => {
    if (!editor) {
        console.error("Invalid editor object.");
        return;
    }

    var selectedText = editor.getSelection();
    if (selectedText === "") { return; }

    var firstFourChars = selectedText.substring(0, 4);
    if (firstFourChars === "<!--") {
        // Uncomment the text
        var uncommentedText = selectedText.substr(4, selectedText.length - 7);
        editor.replaceSelection(uncommentedText);
    } else {
        // Comment the text
        replaceTextInEditor('<!--' + selectedText + '-->', editor);
    }
};

// const updateSummernotePreview = (e) => {
//     let w_height = window.innerHeight;
//     // dokie.find('.note-resizebar').hide();
//     dokie.find('.note-editor').height((w_height - 50) + "px");
//     dokie.find('.note-editable').height((w_height - 120) + "px");
//     // $('#card_data').height('130px');
//     // $('#txt_input').height('80px');
//     dokie.find('#summernote').summernote('code', e.getValue());
//     dokie.find(".CodeMirror").height((w_height - 70) + "px");
// };

const updateSummernotePreview = (editorInstance) => {

    if (isCodeMirrorNotFocused() === true) {
        return false;
    }

    if (!editorInstance || typeof editorInstance.getValue !== 'function') {
        console.error("Invalid editor instance.");
        return;
    }

    // const w_height = window.innerHeight;
    // const editorHeightOffset = 50;
    // const editableHeightOffset = 120;
    // const codeMirrorHeightOffset = 70;

    // const noteEditor = dokie.find('.note-editor');
    // const noteEditable = dokie.find('.note-editable');
    // const codeMirror = dokie.find(".CodeMirror");

    // if (noteEditor.length) {
    //     noteEditor.height((w_height - editorHeightOffset) + "px");
    // }

    // if (noteEditable.length) {
    //     noteEditable.height((w_height - editableHeightOffset) + "px");
    // }
    setSummernoteHeight();
    dokie.find('#summernote').summernote('code', editorInstance.getValue());
    // dokie.find('#summernote').summernote('height', 800);
    // dokie.find('#summernote').css('height', '800px');
    // updateEditorHeights();


};

const setSummernoteHeight = () => {

    const windowHeight = window.innerHeight;
    const editorHeightOffset = 50;
    const editableHeightOffset = 120;
    // $('#summernote').summernote('height', summernoteHeight);

    const noteEditor = dokie.find('.note-editor');
    const noteEditable = dokie.find('.note-editable');

    if (noteEditor.length) {
        noteEditor.height((windowHeight - editorHeightOffset) + "px");
    }

    if (noteEditable.length) {
        noteEditable.height((windowHeight - editableHeightOffset) + "px");
    }

    const summernoteHeight = dokie.find('.note-editor').outerHeight();
    dokie.find(".CodeMirror").height(summernoteHeight);

};

const updateEditorHeights = () => {
    const summernoteHeight = dokie.find('.note-editor').outerHeight();
    dokie.find(".CodeMirror").height(summernoteHeight);
};

const beautifyHtmlInEditor = (editor) => {
    if (!editor || typeof editor.getValue !== 'function' || typeof editor.setValue !== 'function') {
        console.error("Invalid editor object.");
        return;
    }

    let code = editor.getValue();
    if (!code) {
        console.warn("No code to beautify.");
        return;
    }

    try {        
        code = html_beautify(code, { indent_with_tabs: true });
        editor.setValue(code);
        editor.refresh();
    } catch (error) {
        console.error("Error beautifying code:", error);
    }
};

const convertSelectionToList = (editor) => {
    if (!editor || typeof editor.getSelection !== 'function') {
        console.error("Invalid editor object.");
        return;
    }

    var selectedText = editor.getSelection();
    if (selectedText.trim() === "") {
        console.warn("No text selected.");
        return;
    }

    var lines = selectedText.split(/\r\n|\r|\n/);
    var listItems = lines
        .filter(line => line.trim() !== "")
        .map(line => `<li>${line.trim()}</li>`)
        .join("\n");

    replaceTextInEditor(`<ul>\n${listItems}\n</ul>`, editor);
};

function isCodeMirrorNotFocused() {
    return !codemirror_editor.hasFocus();
}

